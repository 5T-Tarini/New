document.getElementById("generateBtn").addEventListener("click", async () => {
    const images = document.getElementById("imageUpload").files;
    const script = document.getElementById("scriptInput").value;

    if (images.length === 0 || script.trim() === "") {
        alert("Please upload images and enter a script.");
        return;
    }

    const formData = new FormData();
    for (let img of images) formData.append("images", img);
    formData.append("script", script);

    const response = await fetch("http://localhost:5000/generate", {
        method: "POST",
        body: formData,
    });

    const data = await response.json();
    if (data.success) {
        document.getElementById("outputVideo").src = data.videoUrl;
        document.getElementById("outputVideo").style.display = "block";
    } else {
        alert("Failed to generate video.");
    }
});
